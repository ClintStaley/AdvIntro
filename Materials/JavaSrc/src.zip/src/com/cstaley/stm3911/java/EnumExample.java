package com.cstaley.stm3911.java;

/*
Demonstrates Java enum features:
- Basic enum syntax
- Enums with properties (fields) and constructors
- Enums with methods
- Enums with abstract methods (each constant implements behavior)
- Printing enums as strings
- Fetching enum values and iterating
- valueOf() for string-to-enum conversion
- Enum ordering and comparison
*/
public class EnumExample {
   /*
   Basic enum: simple list of constants.
   Demonstrates order, string conversion, and iteration.
   */
   public enum DayOfWeek {
      MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY, SUNDAY
   }
   
   /*
   Enum with properties (RGB values) and methods (HSV conversion).
   Each color constant stores its RGB values, and methods convert
   to HSV representation for discussion of color models.
   */
   public enum Color {
      RED(255, 0, 0),
      GREEN(0, 255, 0),
      BLUE(0, 0, 255),
      YELLOW(255, 255, 0),
      CYAN(0, 255, 255),
      MAGENTA(255, 0, 255),
      WHITE(255, 255, 255),
      BLACK(0, 0, 0),
      ORANGE(255, 165, 0),
      PURPLE(128, 0, 128);
      
      private final int red;
      private final int green;
      private final int blue;
      
      Color(int red, int green, int blue) {
         this.red = red;
         this.green = green;
         this.blue = blue;
      }
      
      public int getRed() { return red; }
      public int getGreen() { return green; }
      public int getBlue() { return blue; }
      
      /*
      Get the value (brightness) component of HSV.
      Value is the maximum of R, G, B normalized to 0.0-1.0.
      */
      public double getValue() {
         int max = Math.max(Math.max(red, green), blue);
         return max / 255.0;
      }
      
      /*
      Get the saturation component of HSV.
      Saturation is (max - min) / max, normalized to 0.0-1.0.
      */
      public double getSaturation() {
         int max = Math.max(Math.max(red, green), blue);
         int min = Math.min(Math.min(red, green), blue);
         if (max == 0) return 0.0;
         return (max - min) / (double) max;
      }
      
      /*
      Get the hue component of HSV in degrees (0-360).
      */
      public double getHue() {
         int max = Math.max(Math.max(red, green), blue);
         int min = Math.min(Math.min(red, green), blue);
         int delta = max - min;
         
         if (delta == 0) return 0.0; // Grayscale
         
         double hue = 0.0;
         if (max == red) {
            hue = 60.0 * (((green - blue) / (double) delta) % 6);
         } else if (max == green) {
            hue = 60.0 * (((blue - red) / (double) delta) + 2);
         } else { // max == blue
            hue = 60.0 * (((red - green) / (double) delta) + 4);
         }
         
         if (hue < 0) hue += 360.0;
         return hue;
      }
   }
   
   /*
   Enum with abstract methods: each constant implements different behavior.
   This demonstrates the Strategy pattern using enums.
   */
   public enum Operation {
      PLUS {
         public double apply(double x, double y) { return x + y; }
      },
      MINUS {
         public double apply(double x, double y) { return x - y; }
      },
      TIMES {
         public double apply(double x, double y) { return x * y; }
      },
      DIVIDE {
         public double apply(double x, double y) { return x / y; }
      };
      
      public abstract double apply(double x, double y);
   }
   
   public static void main(String[] args) {
      System.out.println("=== Basic Enum Syntax ===");
      DayOfWeek today = DayOfWeek.MONDAY;
      System.out.println("Today is: " + today);
      System.out.println("Name: " + today.name());
      System.out.println("Ordinal: " + today.ordinal());
      System.out.println();
      
      System.out.println("=== Enum Ordering and Comparison ===");
      DayOfWeek day1 = DayOfWeek.MONDAY;
      DayOfWeek day2 = DayOfWeek.FRIDAY;
      System.out.println(day1 + " compareTo " + day2 + ": " + 
         day1.compareTo(day2));
      System.out.println(day1 + " equals " + day2 + ": " + 
         day1.equals(day2));
      System.out.println(day1 + " == " + day2 + ": " + (day1 == day2));
      System.out.println();
      
      System.out.println("=== Fetching and Iterating Enum Values ===");
      System.out.println("All days of week:");
      DayOfWeek[] allDays = DayOfWeek.values();
      for (DayOfWeek day : allDays) {
         System.out.println("  " + day + " (ordinal: " + day.ordinal() + 
            ")");
      }
      System.out.println();
      
      System.out.println("=== valueOf() - String to Enum Conversion ===");
      String dayStr = "FRIDAY";
      DayOfWeek day = DayOfWeek.valueOf(dayStr);
      System.out.println("Converted '" + dayStr + "' to: " + day);
      
      try {
         DayOfWeek.valueOf("INVALID");
      } catch (IllegalArgumentException e) {
         System.out.println("Error converting 'INVALID': " + 
            e.getMessage());
      }
      System.out.println();
      
      System.out.println("=== Enum with Properties and Methods ===");
      System.out.println("Color RGB and HSV values:");
      for (Color color : Color.values()) {
         System.out.printf("  %s: RGB(%d, %d, %d)  HSV(%.1f°, %.2f, %.2f)%n",
            color, color.getRed(), color.getGreen(), color.getBlue(),
            color.getHue(), color.getSaturation(), color.getValue());
      }
      System.out.println();
      
      System.out.println("=== Enum with Abstract Methods ===");
      double x = 10.0, y = 3.0;
      for (Operation op : Operation.values()) {
         System.out.printf("%.1f %s %.1f = %.2f%n", x, op.name(), y, 
            op.apply(x, y));
      }
      System.out.println();
   }
}
